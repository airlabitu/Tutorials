{\rtf1\ansi\ansicpg1252\cocoartf2639
\cocoatextscaling0\cocoaplatform0{\fonttbl\f0\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;}
{\*\expandedcolortbl;;}
\paperw11900\paperh16840\margl1440\margr1440\vieww11520\viewh8400\viewkind0
\pard\tx566\tx1133\tx1700\tx2267\tx2834\tx3401\tx3968\tx4535\tx5102\tx5669\tx6236\tx6803\pardirnatural\partightenfactor0

\f0\fs24 \cf0 # Measuring weight with load cells and arduino\
With this code we provide a *bare-minimum* example for getting started with load cells. The code is tested using a single 20kg load cell in a kitchen-scale-style setup. The programming will tare the weight when started and following request a calibration weighing of 500 "units" or grams. Full documentation and wiring diagrams can be fouind via [this link](https://airlab.itu.dk/measuring-load-cells-with-arduino/) to AIR LABs webpage\
}